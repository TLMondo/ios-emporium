//
//  Keys.swift
//  DigitalVelocity
//
//  Created by Tealium User on 5/9/18.
//  Copyright © 2018 Jason Koo. All rights reserved.
//

import Foundation

enum Keys {
    static let bugsnag_api_key = "3d9bc9e4f229a6f48fe29a5aa35df733"
    static let instabug_token = "39bca66be0415a250170a9dbd56b029f"
}
